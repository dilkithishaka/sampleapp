package com.example.test_app2;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.test_app2.Database.DBHandler;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    TextView name, txtcompany;
    EditText et_name;
    Spinner sp_company;
    Button save;
    DBHandler dbHandler;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        dbHandler = new DBHandler(this);
       // boolean insert = dbHandler.insertCompanies("kpmg");
//        boolean insertv2 = dbHandler.insertCompanies("ifs");
//        boolean insertv3 = dbHandler.insertCompanies("wso2");
try {
    boolean company = dbHandler.insertCompanies("kpmg",1);
    if (company == true) {
        Toast.makeText(getApplicationContext(), "successfully inserted", Toast.LENGTH_LONG).show();
    } else {
        Toast.makeText(getApplicationContext(), "unsuccessfull", Toast.LENGTH_LONG).show();

    }
}catch (Exception e){
    Log.d("Msd",e.toString());
}


        name = (TextView) findViewById(R.id.textView_name);
        txtcompany = (TextView) findViewById(R.id.textView_Company);
        et_name = (EditText) findViewById(R.id.editText_name);
        sp_company = (Spinner) findViewById(R.id.editText_company);
        save = (Button) findViewById(R.id.button_save);
    }
        //ArrayList<String> company = dbHandler.getAllCompanies();

        //ArrayAdapter<String> adapter_company =new ArrayAdapter<String>(this,R.layout.spinner_layout, R.id.text, company);
//        adapter_company.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //sp_company.setAdapter(adapter_company);
       //sp_company.setPrompt("Choose...");
        //sp_company.setSelection(4);
        //sp_company.setOnItemSelectedListener(this);


//        save.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if (validationSuccess()) {
//                    addDetails();
//                    et_name.setText("");
//                    sp_company.setSelection(0);
//                    Intent intent = new Intent(getApplicationContext(), Activity2.class);
//                    startActivity(intent);
//                } else {
//                    AlertDialog();
//                }
//
//            }
//        });
//
//
//    }
//
//    private void AlertDialog() {
//        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(MainActivity.this);
//        alertDialogBuilder.setMessage("Please ensure all Questions are answered").setCancelable(false).setPositiveButton("OK", new DialogInterface.OnClickListener() {
//            public void onClick(DialogInterface dialog, int id) {
//                dialog.cancel();
//            }
//        });
//
//        AlertDialog alert = alertDialogBuilder.create();
//        alert.show();
//
//    }
//
//    private Boolean validationSuccess() {
//        if (et_name.getText().toString().equalsIgnoreCase("")) {
//            Toast.makeText(getApplicationContext(), "Please enter your name!", Toast.LENGTH_SHORT).show();
//            return false;
//        }
//
//        if (sp_company.getSelectedItemPosition() == 0) {
//            Toast.makeText(getApplicationContext(), "Please Choose a company!", Toast.LENGTH_SHORT).show();
//            return false;
//        }
//        return true;
//    }
//
//

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

//    private void insertCompanies() {
//
//
//        try {
//            boolean isInserted = dbHandler.insertCompanies(sp_company.getSelectedItem().toString());
//
//            if (isInserted == true) {
//                Toast.makeText(MainActivity.this, "Data Inserted", Toast.LENGTH_LONG).show();
//            } else {
//                Toast.makeText(MainActivity.this, "Data is not inserted", Toast.LENGTH_LONG).show();
//            }
//        } catch (Exception e) {
//            Log.d("Msd", e.toString());
//        }
//    }

    private void addDetails() {
        try {
            boolean isInserted = dbHandler.addDetails(et_name.getText().toString(), sp_company.getSelectedItem().toString());

            if (isInserted == true) {
                Toast.makeText(MainActivity.this, "Data Inserted", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(MainActivity.this, "Data is not inserted", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Log.d("Msd", e.toString());
        }
    }
}
