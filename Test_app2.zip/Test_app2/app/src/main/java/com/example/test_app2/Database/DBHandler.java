package com.example.test_app2.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.ArrayAdapter;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DBHandler extends SQLiteOpenHelper {

    public final static int DATABASE_VERSION = 1;
    public final static String DATABASE_NAME = "database2.db";
    public static final String MAIN_TABLE_NAME = "info_table";
    public static final String COMPANY_TABLE = "company_table";


    public static final String COL_1 = "id";
    public static final String COL_2 = "name";
    public static final String COL_3 = "company";

    public static final String COL_1c = "cid";
    public static final String COL_2c = "company_name";

    public DBHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        //SQLiteDatabase db = this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String info_table = "CREATE TABLE " + MAIN_TABLE_NAME + " (" +
                COL_1 + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COL_2 + " TEXT NOT NULL," +
                COL_3 + " TEXT NOT NULL)";

        String company_table = "CREATE TABLE " + COMPANY_TABLE + " (" +
                COL_1c + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COL_2c + " TEXT NOT NULL)";


        db.execSQL(info_table);
        db.execSQL(company_table);

       // db.execSQL("INSERT INTO company_table VALUES('kpmg')");
       // db.execSQL("INSERT INTO company_table VALUES('ifs')");

//        ContentValues contentValues = new ContentValues();
//        contentValues.put(COL_3,"KPMG");
//        contentValues.put(COL_3,"IFS");
//        contentValues.put(COL_3,"FDL");
//        contentValues.put(COL_3,"WSO2");
        //db.insert(MAIN_TABLE_NAME,null,contentValues);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF  EXISTS " + MAIN_TABLE_NAME);
        db.execSQL("DROP TABLE IF  EXISTS " + COMPANY_TABLE);
        onCreate(db);

    }

        public boolean insertCompanies(String company_name,int cid) {

            SQLiteDatabase db = getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put(COL_1c,cid);
            values.put(COL_2c,company_name);

            long results = db.insert(COMPANY_TABLE, null,values);
            try{
                if (results == -1) {
                    return  false;
                } else {
                    return true;
                }
            }
            catch(SQLException e){
                Log.d("Msd",e.toString());
            }
            return true;
        }

        // Open the database for writing
//        SQLiteDatabase db = this.getWritableDatabase();
//        // Start the transaction.
//        db.beginTransaction();
//        ContentValues values;
//
//        values = new ContentValues();
//        values.put(COL_2,company);
//        // Insert Row
//        db.insert(MAIN_TABLE_NAME, null, values);
//        // Insert into database successfully.
//        db.setTransactionSuccessful();





//        public List<String> getAllCompanies(){
//        List<String> companies = new ArrayList<String>();
//
//        // Select All Query
//        String selectQuery = "SELECT  * FROM " + MAIN_TABLE_NAME;
//
//        SQLiteDatabase db = this.getReadableDatabase();
//        Cursor cursor = db.rawQuery(selectQuery, null);
//
//        // looping through all rows and adding to list
//        if (cursor.moveToFirst()) {
//            do {
//                companies.add(cursor.getString(1));
//            } while (cursor.moveToNext());
//        }
//
//        // closing connection
//        cursor.close();
//        db.close();
//
//        // returning lables
//        return companies;
//    }

//
//    public ArrayList<String> getAllCompanies() {
//
//        ArrayList<String> companies = new ArrayList<String>();
//        // Open the database for reading
//        SQLiteDatabase db = this.getReadableDatabase();
//        // Start the transaction.
//        db.beginTransaction();
//
//
//        String selectQuery = "SELECT * FROM " + MAIN_TABLE_NAME;
//        Cursor cursor = db.rawQuery(selectQuery, null);
//        try {
//            if (cursor.getCount() > 0) {
//                while (cursor.moveToNext()) {
//                    // Add province name to arraylist
//                    String company = cursor.getString(cursor.getColumnIndex("company"));
//                    companies.add(company);
//
//                }
//            }
//            db.setTransactionSuccessful();
//        }
//        catch (SQLException e){
//            e.printStackTrace();
//        }
//
//        finally{
//            db.endTransaction();
//            // End the transaction.
//            db.close();
//
//        }
//        return companies;
//    }



    public boolean addDetails(String name,String company) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(COL_2,name);
        values.put(COL_3,company );

        long results = db.insert(MAIN_TABLE_NAME, null, values);
        try{
            if (results == -1) {
                return  false;
            } else {
                return true;
            }
        }
        catch(SQLException e){
            Log.d("Msd",e.toString());
        }
        return true;
    }

}
